Welcome to Snake game
Created by StartPimp47

<-<-<-<-<-<-<-<-<

You can translate this file if you want ;)

There are 3 snakes : You, Blueper and Tomb Reder.
There are 2 apples and 1 banana.
Tomb Reder go to just one apple.
Blueper go to the banana.

The banana give for all snakes 2 squares.
The apples give for all snakes 1 square.

The snakes can die when he collision in other snakes but not with himself.
The snakes can eat all foods.
When you die your score is reset at 0.
The snakes have infinite lives.
When I say "snakes", I talk about you too.
You can save the game with the button "s".
You can restart the game with the button "r".
You can able or disable the auto save with the button "a".
You can change the colors of the snakes in the file "save.txt". The colors can just be in their hexadecimal color code.

If the snakes make something that is strange push the button "r". Do not cloase the game because, with that, your game is corrupted.

